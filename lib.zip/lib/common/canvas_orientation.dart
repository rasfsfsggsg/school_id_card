enum CanvasOrientation {
  horizontal,
  vertical,

}
